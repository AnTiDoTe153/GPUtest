﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GPUTest2.Models
{
    public class Data
    {
        public int DataID { get; set; }

        public int fps { get; set; }
        public string stuff { get; set; }

    }
}